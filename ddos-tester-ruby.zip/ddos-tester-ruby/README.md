# README.md for DDoS Tester (Ruby)

## Overview
**DDoS Tester** is a lightweight Ruby-based HTTP GET flood tool designed strictly for **educational and legal purposes only**. It allows ethical hackers, developers, and system administrators to test the resilience of their **own websites** against simulated HTTP flood traffic.

> **Warning:** This tool must **only** be used on systems you own or have explicit permission to test. Unauthorized usage is illegal.

---

## Features
- Fully written in Ruby
- Lightweight and fast for low-spec Android (Termux) devices
- HTTPS support (via OpenSSL)
- Threaded request system
- Easy to customize and expand

---

## Requirements
- Ruby (2.5+)
- Termux (Android)

### Installation (Termux):
```bash
pkg update && pkg upgrade
pkg install ruby git
```

### Clone and Run:
```bash
git clone https://github.com/your-username/ddos-tester-ruby
cd ddos-tester-ruby
ruby ddos-tester.rb
```

---

## How to Use
1. Enter the full URL of the target (must include `http://` or `https://`).
2. Enter number of threads (e.g., 50).
3. Enter how long the test should run in seconds (e.g., 30).

Example:
```
Enter target URL (e.g., https://example.com): https://yourwebsite.com
Enter number of threads to use: 50
Enter duration in seconds: 30
```

---

## License
Copyright (c) 2025 - This code is licensed only to ethical users. Redistribution, modification, or malicious use is strictly prohibited.

---

## Disclaimer
> This tool is for educational use **only**. The developer is **not responsible** for any misuse or illegal activities performed with this script.

Use responsibly.
